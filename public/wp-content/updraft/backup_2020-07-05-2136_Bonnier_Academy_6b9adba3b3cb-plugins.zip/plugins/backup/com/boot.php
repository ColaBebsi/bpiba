<?php
require_once(dirname(__FILE__).'/config/config.wordpress.free.php');
require_once(dirname(__FILE__).'/config/config.wordpress.php');
require_once(SG_CORE_PATH.'SGBoot.php');

SGBoot::init();
