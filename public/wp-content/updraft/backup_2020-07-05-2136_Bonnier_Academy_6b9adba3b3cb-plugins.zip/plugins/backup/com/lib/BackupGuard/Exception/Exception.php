<?php

namespace BackupGuard;

class Exception extends \Exception
{

}
