<?php

class SGArchiveToZip
{
	public function __construct()
	{
		$this->backupFiles = new SGBackupFiles();
	}
	
	private $filePath;
	private $fileName;
	
	public function setFilePath($filePath)
	{
		$this->filePath = $filePath;
	}
	
	public function getFilePath()
	{
		return $this->filePath;
	}
	
	public function setFileName($fileName)
	{
		$this->fileName = $fileName;
	}
	
	public function getFileName()
	{
		return $this->fileName;
	}
	
	public function convert()
	{
		$this->extract();
	}
	
	private function extract()
	{
		$backupName = $this->getFileName();
		$backupName = backupGuardRemoveSlashes($backupName);
		$backupPath = SG_BACKUP_DIRECTORY.$backupName;
		$filePath = $backupPath.'/'.$backupName.'.sgbp';
	
		$files = new SGBackup();
		$files->extractForZip($filePath, $backupPath, $backupName);
		//$files->extractBackupByPath($backupPath.'/'.$backupName.'.sgbp', $backupName);
	}
}