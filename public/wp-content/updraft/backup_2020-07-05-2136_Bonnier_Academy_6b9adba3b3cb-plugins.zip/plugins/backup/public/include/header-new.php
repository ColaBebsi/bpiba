<?php SGNotice::getInstance()->renderAll(); ?>
<div class="sg-spinner"></div>
<div class="bg-container">
	<div id="bg-wrapper">
