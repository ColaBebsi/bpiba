<div class="sg-error-notice-wrapper">
	<h2 class="sg-red-color sg-notice-error-h2">
		PHP EXECUTION TIMEOUT ERROR
	</h2>
	<p class="sg-red-color sg-notice-error-p">
		Oops... Seems there was an issue during the backup process.
		<br>
		Let our support representatives know about it by pressing here:
	</p>
	<div class="sg-wrapper-less sg-notice-contact-wrapper">
		<a href="<?php echo BACKUP_GUARD_WORDPRESS_SUPPORT_URL; ?>" class="btn btn-success" target="_blank">Contact us</a>
	</div>
</div>
