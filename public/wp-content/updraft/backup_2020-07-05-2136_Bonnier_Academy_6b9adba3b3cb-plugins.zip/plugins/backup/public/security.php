<?php

	require_once(dirname(__FILE__).'/boot.php');
	require_once(SG_PUBLIC_INCLUDE_PATH.'header.php');
	require_once(SG_PUBLIC_INCLUDE_PATH.'sidebar.php');

?>
<div id="sg-content-wrapper">
	<?php require_once(SG_PUBLIC_INCLUDE_PATH.'footer.php'); ?>
</div>
