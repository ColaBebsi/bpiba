<?php

require_once(dirname(__FILE__).'/../boot.php');

SGConfig::set('SG_HIDE_DISCOUNT_NOTICE', 1);
